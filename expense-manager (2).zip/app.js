// ExpenseTracker Pro - Main Application
class ExpenseTracker {
    constructor() {
        this.transactions = this.loadTransactions();
        this.categories = ['Food & Dining', 'Transportation', 'Entertainment', 'Shopping', 'Bills & Utilities', 'Healthcare', 'Travel', 'Education', 'Other'];
        this.paymentMethods = ['Cash', 'Credit Card', 'Debit Card', 'Bank Transfer', 'Mobile Payment', 'Check'];
        this.currentPageName = 'home';
        this.currentFilter = 'month';
        this.currentSort = { field: 'date', order: 'desc' };
        this.currentPageNum = 1;
        this.itemsPerPage = 10;
        this.editingTransactionId = null;
        this.searchQuery = '';
        this.currentReportView = 'category';
        this.currentReportPeriod = 'month';
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSettings();
        this.populateSelects();
        this.showPage('home');
        this.updateSummaryCards();
        this.renderCharts();
        this.setTodayDate();
        
        // Load sample data if no transactions exist
        if (this.transactions.length === 0) {
            this.loadSampleData();
        }
    }

    loadSampleData() {
        const sampleTransactions = [
            {
                id: this.generateId(),
                date: "2024-08-02",
                description: "Grocery Shopping",
                amount: 85.50,
                category: "Food & Dining",
                paymentMethod: "Credit Card",
                notes: "Weekly groceries at SuperMart"
            },
            {
                id: this.generateId(),
                date: "2024-08-01",
                description: "Gas Station",
                amount: 45.00,
                category: "Transportation",
                paymentMethod: "Debit Card",
                notes: "Fuel for car"
            },
            {
                id: this.generateId(),
                date: "2024-07-31",
                description: "Coffee Shop",
                amount: 12.50,
                category: "Food & Dining",
                paymentMethod: "Cash",
                notes: "Morning coffee"
            }
        ];
        
        this.transactions = sampleTransactions;
        this.saveTransactions();
        this.updateSummaryCards();
        this.renderCharts();
    }

    setupEventListeners() {
        // Navigation - Fixed routing
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const page = item.dataset.page;
                this.showPage(page);
            });
        });

        // Floating add button - Fixed routing
        document.getElementById('floatingAddBtn').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.showPage('add-transaction');
        });

        // Hamburger menu
        document.querySelector('.hamburger-menu').addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.toggleSidebar();
        });

        // Transaction form
        document.getElementById('transactionForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTransaction();
        });

        document.getElementById('resetForm').addEventListener('click', (e) => {
            e.preventDefault();
            this.resetTransactionForm();
        });

        // Autocomplete for description
        document.getElementById('transactionDescription').addEventListener('input', (e) => {
            this.showAutocomplete(e.target, 'description');
        });

        // Transaction filters - Fixed to prevent navigation
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.setFilter(e.target.dataset.period);
            });
        });

        // Custom date range
        document.getElementById('applyCustomRange').addEventListener('click', (e) => {
            e.preventDefault();
            this.applyCustomDateRange();
        });

        // Search functionality
        document.getElementById('searchTransactions').addEventListener('input', (e) => {
            this.searchTransactions(e.target.value);
        });

        // Table sorting
        document.querySelectorAll('[data-sort]').forEach(header => {
            header.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.sortTransactions(header.dataset.sort);
            });
        });

        // Report controls
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.setReportView(e.target.dataset.view);
            });
        });

        document.querySelectorAll('.period-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.setReportPeriod(e.target.dataset.period);
            });
        });

        document.getElementById('exportReport').addEventListener('click', (e) => {
            e.preventDefault();
            this.exportReport();
        });

        // Settings
        document.getElementById('darkModeToggle').addEventListener('change', (e) => {
            this.toggleDarkMode(e.target.checked);
        });

        document.getElementById('exportData').addEventListener('click', (e) => {
            e.preventDefault();
            this.exportData();
        });

        document.getElementById('importData').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('importDataInput').click();
        });

        document.getElementById('importDataInput').addEventListener('change', (e) => {
            this.importData(e.target.files[0]);
        });

        document.getElementById('clearAllData').addEventListener('click', (e) => {
            e.preventDefault();
            this.confirmClearData();
        });

        // Summary cards click
        document.querySelectorAll('.summary-card').forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const filter = card.dataset.filter;
                if (filter !== 'balance') {
                    this.showPage('transactions');
                    this.setFilter(filter);
                }
            });
        });

        // Modal handlers
        this.setupModalHandlers();

        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.autocomplete-container')) {
                this.hideAllAutocomplete();
            }
        });
    }

    setupModalHandlers() {
        // Confirm modal
        document.getElementById('confirmCancel').addEventListener('click', (e) => {
            e.preventDefault();
            this.hideModal('confirmModal');
        });

        document.getElementById('confirmOk').addEventListener('click', (e) => {
            e.preventDefault();
            if (this.pendingAction) {
                this.pendingAction();
                this.pendingAction = null;
            }
            this.hideModal('confirmModal');
        });

        // Edit modal
        document.getElementById('editCancel').addEventListener('click', (e) => {
            e.preventDefault();
            this.hideModal('editModal');
            this.editingTransactionId = null;
        });

        document.getElementById('editTransactionForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateTransaction();
        });

        // Close modals on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal(modal.id);
                }
            });
        });
    }

    // Navigation - Fixed page routing
    showPage(pageName) {
        // Update sidebar active state
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeItem = document.querySelector(`.sidebar-item[data-page="${pageName}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }

        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.add('hidden');
        });

        // Show selected page
        const targetPage = document.getElementById(`${pageName}-page`);
        if (targetPage) {
            targetPage.classList.remove('hidden');
        }

        this.currentPageName = pageName;

        // Load page-specific data
        switch (pageName) {
            case 'transactions':
                this.loadTransactionsPage();
                break;
            case 'reports':
                this.loadReportsPage();
                break;
            case 'add-transaction':
                this.resetTransactionForm();
                break;
        }

        // Close sidebar on mobile
        if (window.innerWidth <= 768) {
            this.closeSidebar();
        }
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const hamburger = document.querySelector('.hamburger-menu');
        
        sidebar.classList.toggle('open');
        hamburger.classList.toggle('active');
    }

    closeSidebar() {
        const sidebar = document.getElementById('sidebar');
        const hamburger = document.querySelector('.hamburger-menu');
        
        sidebar.classList.remove('open');
        hamburger.classList.remove('active');
    }

    // Data Management
    loadTransactions() {
        const stored = localStorage.getItem('expenseTracker_transactions');
        return stored ? JSON.parse(stored) : [];
    }

    saveTransactions() {
        localStorage.setItem('expenseTracker_transactions', JSON.stringify(this.transactions));
    }

    generateId() {
        return Date.now() + Math.random().toString(36).substr(2, 9);
    }

    // Transaction CRUD
    saveTransaction() {
        const transaction = {
            id: this.generateId(),
            date: document.getElementById('transactionDate').value,
            description: document.getElementById('transactionDescription').value,
            amount: parseFloat(document.getElementById('transactionAmount').value),
            category: document.getElementById('transactionCategory').value,
            paymentMethod: document.getElementById('transactionPaymentMethod').value,
            notes: document.getElementById('transactionNotes').value
        };

        if (this.validateTransaction(transaction)) {
            this.transactions.push(transaction);
            this.saveTransactions();
            this.updateSummaryCards();
            this.renderCharts();
            
            // Show success message
            this.showNotification('Transaction saved successfully!', 'success');
            
            // Reset form
            this.resetTransactionForm();
            
            // Navigate to transactions page
            this.showPage('transactions');
        }
    }

    validateTransaction(transaction) {
        if (!transaction.date || !transaction.description || !transaction.amount || 
            !transaction.category || !transaction.paymentMethod) {
            this.showNotification('Please fill in all required fields', 'error');
            return false;
        }

        if (transaction.amount <= 0) {
            this.showNotification('Amount must be greater than 0', 'error');
            return false;
        }

        return true;
    }

    updateTransaction() {
        const transaction = {
            id: this.editingTransactionId,
            date: document.getElementById('editDate').value,
            description: document.getElementById('editDescription').value,
            amount: parseFloat(document.getElementById('editAmount').value),
            category: document.getElementById('editCategory').value,
            paymentMethod: document.getElementById('editPaymentMethod').value,
            notes: document.getElementById('editNotes').value
        };

        if (this.validateTransaction(transaction)) {
            const index = this.transactions.findIndex(t => t.id === this.editingTransactionId);
            if (index !== -1) {
                this.transactions[index] = transaction;
                this.saveTransactions();
                this.updateSummaryCards();
                this.renderCharts();
                this.loadTransactionsPage();
                
                this.showNotification('Transaction updated successfully!', 'success');
                this.hideModal('editModal');
                this.editingTransactionId = null;
            }
        }
    }

    deleteTransaction(id) {
        this.showConfirmModal(
            'Delete Transaction',
            'Are you sure you want to delete this transaction? This action cannot be undone.',
            () => {
                this.transactions = this.transactions.filter(t => t.id !== id);
                this.saveTransactions();
                this.updateSummaryCards();
                this.renderCharts();
                this.loadTransactionsPage();
                this.showNotification('Transaction deleted successfully!', 'success');
            }
        );
    }

    duplicateTransaction(id) {
        const transaction = this.transactions.find(t => t.id === id);
        if (transaction) {
            const duplicate = {
                ...transaction,
                id: this.generateId(),
                date: new Date().toISOString().split('T')[0]
            };
            
            this.transactions.push(duplicate);
            this.saveTransactions();
            this.updateSummaryCards();
            this.renderCharts();
            this.loadTransactionsPage();
            this.showNotification('Transaction duplicated successfully!', 'success');
        }
    }

    editTransaction(id) {
        const transaction = this.transactions.find(t => t.id === id);
        if (transaction) {
            this.editingTransactionId = id;
            
            // Populate edit form
            document.getElementById('editDate').value = transaction.date;
            document.getElementById('editDescription').value = transaction.description;
            document.getElementById('editAmount').value = transaction.amount;
            document.getElementById('editCategory').value = transaction.category;
            document.getElementById('editPaymentMethod').value = transaction.paymentMethod;
            document.getElementById('editNotes').value = transaction.notes;
            
            this.showModal('editModal');
        }
    }

    // Summary and Dashboard
    updateSummaryCards() {
        const today = new Date().toISOString().split('T')[0];
        const thisWeekStart = this.getWeekStart(new Date());
        const thisMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];

        const todayExpenses = this.getExpensesForPeriod(today, today);
        const weekExpenses = this.getExpensesForPeriod(thisWeekStart, today);
        const monthExpenses = this.getExpensesForPeriod(thisMonthStart, today);
        const totalExpenses = this.transactions.reduce((sum, t) => sum + t.amount, 0);

        document.getElementById('todayAmount').textContent = this.formatCurrency(todayExpenses);
        document.getElementById('weekAmount').textContent = this.formatCurrency(weekExpenses);
        document.getElementById('monthAmount').textContent = this.formatCurrency(monthExpenses);
        document.getElementById('totalBalance').textContent = this.formatCurrency(-totalExpenses);
    }

    getExpensesForPeriod(startDate, endDate) {
        return this.transactions
            .filter(t => t.date >= startDate && t.date <= endDate)
            .reduce((sum, t) => sum + t.amount, 0);
    }

    getWeekStart(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day;
        return new Date(d.setDate(diff)).toISOString().split('T')[0];
    }

    // Charts
    renderCharts() {
        this.renderPieChart();
        this.renderBarChart();
    }

    renderPieChart() {
        const canvas = document.getElementById('pieChart');
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Get category data
        const categoryData = this.getCategoryData();
        
        if (categoryData.length === 0) {
            ctx.font = '16px Arial';
            ctx.fillStyle = '#666';
            ctx.textAlign = 'center';
            ctx.fillText('No data available', canvas.width / 2, canvas.height / 2);
            return;
        }

        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454'];
        
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = Math.min(centerX, centerY) - 20;
        let currentAngle = 0;

        categoryData.forEach((item, index) => {
            const sliceAngle = (item.amount / categoryData.reduce((sum, cat) => sum + cat.amount, 0)) * 2 * Math.PI;
            
            // Draw slice
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            ctx.lineTo(centerX, centerY);
            ctx.fillStyle = colors[index % colors.length];
            ctx.fill();
            
            // Draw label
            const labelAngle = currentAngle + sliceAngle / 2;
            const labelX = centerX + Math.cos(labelAngle) * (radius - 30);
            const labelY = centerY + Math.sin(labelAngle) * (radius - 30);
            
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(item.category, labelX, labelY);
            
            currentAngle += sliceAngle;
        });

        // Add click handler
        canvas.onclick = (e) => {
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = canvas.width / 2;
            const centerY = canvas.height / 2;
            const clickAngle = Math.atan2(y - centerY, x - centerX);
            
            // Determine which slice was clicked
            let currentAngle = 0;
            for (let i = 0; i < categoryData.length; i++) {
                const sliceAngle = (categoryData[i].amount / categoryData.reduce((sum, cat) => sum + cat.amount, 0)) * 2 * Math.PI;
                if (clickAngle >= currentAngle && clickAngle <= currentAngle + sliceAngle) {
                    this.filterByCategory(categoryData[i].category);
                    break;
                }
                currentAngle += sliceAngle;
            }
        };
    }

    renderBarChart() {
        const canvas = document.getElementById('barChart');
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Get daily data for the last 7 days
        const dailyData = this.getDailyData();
        
        if (dailyData.length === 0) {
            ctx.font = '16px Arial';
            ctx.fillStyle = '#666';
            ctx.textAlign = 'center';
            ctx.fillText('No data available', canvas.width / 2, canvas.height / 2);
            return;
        }

        const barWidth = (canvas.width - 40) / dailyData.length;
        const maxAmount = Math.max(...dailyData.map(d => d.amount));
        const chartHeight = canvas.height - 60;

        dailyData.forEach((item, index) => {
            const barHeight = (item.amount / maxAmount) * chartHeight;
            const x = 20 + index * barWidth;
            const y = canvas.height - 40 - barHeight;

            // Draw bar
            ctx.fillStyle = '#1FB8CD';
            ctx.fillRect(x + 5, y, barWidth - 10, barHeight);

            // Draw label
            ctx.fillStyle = '#666';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(item.date, x + barWidth / 2, canvas.height - 10);
            
            // Draw amount
            ctx.fillStyle = '#333';
            ctx.fillText(`$${item.amount.toFixed(0)}`, x + barWidth / 2, y - 5);
        });
    }

    getCategoryData() {
        const categoryTotals = {};
        this.transactions.forEach(transaction => {
            categoryTotals[transaction.category] = (categoryTotals[transaction.category] || 0) + transaction.amount;
        });

        return Object.entries(categoryTotals)
            .map(([category, amount]) => ({ category, amount }))
            .sort((a, b) => b.amount - a.amount);
    }

    getDailyData() {
        const last7Days = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            
            const dayTotal = this.transactions
                .filter(t => t.date === dateStr)
                .reduce((sum, t) => sum + t.amount, 0);
            
            last7Days.push({
                date: date.toLocaleDateString('en-US', { weekday: 'short' }),
                amount: dayTotal
            });
        }
        return last7Days;
    }

    filterByCategory(category) {
        this.showPage('transactions');
        // Apply category filter logic here
        this.loadTransactionsPage();
    }

    // Transactions Page
    loadTransactionsPage() {
        this.renderTransactionsTable();
        this.updateRunningTotal();
        this.renderPagination();
    }

    setFilter(period) {
        // Update active filter button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeBtn = document.querySelector(`.filter-btn[data-period="${period}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }

        // Show/hide custom date range
        const customRange = document.getElementById('customDateRange');
        if (period === 'custom') {
            customRange.classList.remove('hidden');
        } else {
            customRange.classList.add('hidden');
            this.currentFilter = period;
            this.loadTransactionsPage();
        }
    }

    applyCustomDateRange() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        if (startDate && endDate) {
            this.currentFilter = { type: 'custom', start: startDate, end: endDate };
            this.loadTransactionsPage();
        }
    }

    getFilteredTransactions() {
        let filtered = [...this.transactions];
        
        if (typeof this.currentFilter === 'string') {
            const today = new Date().toISOString().split('T')[0];
            let startDate;
            
            switch (this.currentFilter) {
                case 'today':
                    startDate = today;
                    break;
                case 'week':
                    startDate = this.getWeekStart(new Date());
                    break;
                case 'month':
                    startDate = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
                    break;
                case 'year':
                    startDate = new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0];
                    break;
                default:
                    return filtered;
            }
            
            filtered = filtered.filter(t => t.date >= startDate && t.date <= today);
        } else if (this.currentFilter.type === 'custom') {
            filtered = filtered.filter(t => 
                t.date >= this.currentFilter.start && t.date <= this.currentFilter.end
            );
        }
        
        return filtered;
    }

    searchTransactions(query) {
        this.searchQuery = query.toLowerCase();
        this.loadTransactionsPage();
    }

    sortTransactions(field) {
        if (this.currentSort.field === field) {
            this.currentSort.order = this.currentSort.order === 'asc' ? 'desc' : 'asc';
        } else {
            this.currentSort.field = field;
            this.currentSort.order = 'asc';
        }
        
        this.loadTransactionsPage();
    }

    renderTransactionsTable() {
        let transactions = this.getFilteredTransactions();
        
        // Apply search filter
        if (this.searchQuery) {
            transactions = transactions.filter(t => 
                t.description.toLowerCase().includes(this.searchQuery) ||
                t.category.toLowerCase().includes(this.searchQuery) ||
                t.paymentMethod.toLowerCase().includes(this.searchQuery) ||
                t.notes.toLowerCase().includes(this.searchQuery)
            );
        }
        
        // Apply sorting
        transactions.sort((a, b) => {
            let aVal = a[this.currentSort.field];
            let bVal = b[this.currentSort.field];
            
            if (this.currentSort.field === 'amount') {
                aVal = parseFloat(aVal);
                bVal = parseFloat(bVal);
            }
            
            if (this.currentSort.order === 'asc') {
                return aVal > bVal ? 1 : -1;
            } else {
                return aVal < bVal ? 1 : -1;
            }
        });
        
        // Pagination
        const startIndex = (this.currentPageNum - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const paginatedTransactions = transactions.slice(startIndex, endIndex);
        
        const tbody = document.getElementById('transactionsTableBody');
        tbody.innerHTML = '';
        
        paginatedTransactions.forEach(transaction => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${this.formatDate(transaction.date)}</td>
                <td>${transaction.description}</td>
                <td>${this.formatCurrency(transaction.amount)}</td>
                <td>${transaction.category}</td>
                <td>${transaction.paymentMethod}</td>
                <td class="transaction-actions">
                    <button class="action-btn edit" onclick="app.editTransaction('${transaction.id}')" title="Edit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                        </svg>
                    </button>
                    <button class="action-btn duplicate" onclick="app.duplicateTransaction('${transaction.id}')" title="Duplicate">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
                        </svg>
                    </button>
                    <button class="action-btn delete" onclick="app.deleteTransaction('${transaction.id}')" title="Delete">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                        </svg>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
        this.totalFilteredTransactions = transactions.length;
    }

    updateRunningTotal() {
        const transactions = this.getFilteredTransactions();
        const total = transactions.reduce((sum, t) => sum + t.amount, 0);
        document.getElementById('runningTotal').textContent = this.formatCurrency(total);
    }

    renderPagination() {
        const totalPages = Math.ceil(this.totalFilteredTransactions / this.itemsPerPage);
        const pagination = document.getElementById('pagination');
        pagination.innerHTML = '';
        
        if (totalPages <= 1) return;
        
        // Previous button
        const prevBtn = document.createElement('button');
        prevBtn.textContent = 'Previous';
        prevBtn.disabled = this.currentPageNum === 1;
        prevBtn.onclick = () => this.goToPage(this.currentPageNum - 1);
        pagination.appendChild(prevBtn);
        
        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.classList.toggle('active', i === this.currentPageNum);
            pageBtn.onclick = () => this.goToPage(i);
            pagination.appendChild(pageBtn);
        }
        
        // Next button
        const nextBtn = document.createElement('button');
        nextBtn.textContent = 'Next';
        nextBtn.disabled = this.currentPageNum === totalPages;
        nextBtn.onclick = () => this.goToPage(this.currentPageNum + 1);
        pagination.appendChild(nextBtn);
    }

    goToPage(page) {
        this.currentPageNum = page;
        this.renderTransactionsTable();
        this.renderPagination();
    }

    // Reports
    loadReportsPage() {
        this.currentReportView = 'category';
        this.currentReportPeriod = 'month';
        this.generateReport();
    }

    setReportView(view) {
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeBtn = document.querySelector(`.toggle-btn[data-view="${view}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
        
        this.currentReportView = view;
        this.generateReport();
    }

    setReportPeriod(period) {
        document.querySelectorAll('.period-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeBtn = document.querySelector(`.period-btn[data-period="${period}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
        
        this.currentReportPeriod = period;
        this.generateReport();
    }

    generateReport() {
        const transactions = this.getTransactionsForReportPeriod();
        const reportData = this.aggregateReportData(transactions);
        
        this.renderReportTable(reportData);
        this.renderReportChart(reportData);
    }

    getTransactionsForReportPeriod() {
        const today = new Date().toISOString().split('T')[0];
        let startDate;
        
        switch (this.currentReportPeriod) {
            case 'today':
                startDate = today;
                break;
            case 'week':
                startDate = this.getWeekStart(new Date());
                break;
            case 'month':
                startDate = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
                break;
            case 'year':
                startDate = new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0];
                break;
        }
        
        return this.transactions.filter(t => t.date >= startDate && t.date <= today);
    }

    aggregateReportData(transactions) {
        const data = {};
        
        transactions.forEach(transaction => {
            const key = transaction[this.currentReportView];
            data[key] = (data[key] || 0) + transaction.amount;
        });
        
        return Object.entries(data)
            .map(([key, amount]) => ({ key, amount }))
            .sort((a, b) => b.amount - a.amount);
    }

    renderReportTable(data) {
        const thead = document.getElementById('reportTableHead');
        const tbody = document.getElementById('reportTableBody');
        
        // Set headers
        const viewLabel = this.currentReportView.charAt(0).toUpperCase() + this.currentReportView.slice(1);
        thead.innerHTML = `
            <tr>
                <th>${viewLabel}</th>
                <th>Amount</th>
                <th>Percentage</th>
            </tr>
        `;
        
        // Calculate total
        const total = data.reduce((sum, item) => sum + item.amount, 0);
        
        // Populate rows
        tbody.innerHTML = '';
        data.forEach(item => {
            const percentage = ((item.amount / total) * 100).toFixed(1);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.key}</td>
                <td>${this.formatCurrency(item.amount)}</td>
                <td>${percentage}%</td>
            `;
            tbody.appendChild(row);
        });
        
        // Add total row
        const totalRow = document.createElement('tr');
        totalRow.className = 'grand-total';
        totalRow.innerHTML = `
            <td><strong>Total</strong></td>
            <td><strong>${this.formatCurrency(total)}</strong></td>
            <td><strong>100%</strong></td>
        `;
        tbody.appendChild(totalRow);
    }

    renderReportChart(data) {
        const canvas = document.getElementById('reportChart');
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        if (data.length === 0) {
            ctx.font = '16px Arial';
            ctx.fillStyle = '#666';
            ctx.textAlign = 'center';
            ctx.fillText('No data available', canvas.width / 2, canvas.height / 2);
            return;
        }
        
        // Render as horizontal bar chart
        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454'];
        const maxAmount = Math.max(...data.map(d => d.amount));
        const barHeight = 30;
        const barSpacing = 10;
        const startY = 20;
        
        data.forEach((item, index) => {
            const barWidth = (item.amount / maxAmount) * (canvas.width - 150);
            const y = startY + index * (barHeight + barSpacing);
            
            // Draw bar
            ctx.fillStyle = colors[index % colors.length];
            ctx.fillRect(120, y, barWidth, barHeight);
            
            // Draw label
            ctx.fillStyle = '#333';
            ctx.font = '12px Arial';
            ctx.textAlign = 'right';
            ctx.fillText(item.key, 115, y + barHeight / 2 + 4);
            
            // Draw amount
            ctx.textAlign = 'left';
            ctx.fillText(this.formatCurrency(item.amount), 125 + barWidth, y + barHeight / 2 + 4);
        });
    }

    exportReport() {
        const transactions = this.getTransactionsForReportPeriod();
        const reportData = this.aggregateReportData(transactions);
        
        // Create CSV content
        let csvContent = `${this.currentReportView.charAt(0).toUpperCase() + this.currentReportView.slice(1)},Amount,Percentage\n`;
        
        const total = reportData.reduce((sum, item) => sum + item.amount, 0);
        reportData.forEach(item => {
            const percentage = ((item.amount / total) * 100).toFixed(1);
            csvContent += `"${item.key}",${item.amount},${percentage}%\n`;
        });
        
        csvContent += `Total,${total},100%\n`;
        
        // Download file
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `expense-report-${this.currentReportPeriod}-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
        
        this.showNotification('Report exported successfully!', 'success');
    }

    // Autocomplete
    showAutocomplete(input, type) {
        const dropdown = input.parentElement.querySelector('.autocomplete-dropdown');
        const value = input.value.toLowerCase();
        
        if (value.length < 2) {
            dropdown.style.display = 'none';
            return;
        }
        
        let suggestions = [];
        
        if (type === 'description') {
            const descriptions = [...new Set(this.transactions.map(t => t.description))];
            suggestions = descriptions.filter(desc => 
                desc.toLowerCase().includes(value)
            );
            
            // Auto-fill other fields based on description
            const matchingTransaction = this.transactions.find(t => 
                t.description.toLowerCase() === value
            );
            
            if (matchingTransaction) {
                document.getElementById('transactionCategory').value = matchingTransaction.category;
                document.getElementById('transactionPaymentMethod').value = matchingTransaction.paymentMethod;
                document.getElementById('transactionAmount').value = matchingTransaction.amount;
            }
        }
        
        if (suggestions.length === 0) {
            dropdown.style.display = 'none';
            return;
        }
        
        dropdown.innerHTML = '';
        suggestions.slice(0, 5).forEach(suggestion => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.textContent = suggestion;
            item.onclick = () => {
                input.value = suggestion;
                dropdown.style.display = 'none';
                
                // Trigger autofill for description
                if (type === 'description') {
                    const event = new Event('input');
                    input.dispatchEvent(event);
                }
            };
            dropdown.appendChild(item);
        });
        
        dropdown.style.display = 'block';
    }

    hideAllAutocomplete() {
        document.querySelectorAll('.autocomplete-dropdown').forEach(dropdown => {
            dropdown.style.display = 'none';
        });
    }

    // Form Management
    populateSelects() {
        const categorySelect = document.getElementById('transactionCategory');
        const paymentSelect = document.getElementById('transactionPaymentMethod');
        const editCategorySelect = document.getElementById('editCategory');
        const editPaymentSelect = document.getElementById('editPaymentMethod');
        
        // Clear existing options (except first)
        [categorySelect, editCategorySelect].forEach(select => {
            while (select.children.length > 1) {
                select.removeChild(select.lastChild);
            }
        });
        
        [paymentSelect, editPaymentSelect].forEach(select => {
            while (select.children.length > 1) {
                select.removeChild(select.lastChild);
            }
        });
        
        // Add categories
        this.categories.forEach(category => {
            [categorySelect, editCategorySelect].forEach(select => {
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category;
                select.appendChild(option);
            });
        });
        
        // Add payment methods
        this.paymentMethods.forEach(method => {
            [paymentSelect, editPaymentSelect].forEach(select => {
                const option = document.createElement('option');
                option.value = method;
                option.textContent = method;
                select.appendChild(option);
            });
        });
    }

    setTodayDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('transactionDate').value = today;
    }

    resetTransactionForm() {
        document.getElementById('transactionForm').reset();
        this.setTodayDate();
        this.hideAllAutocomplete();
    }

    // Settings
    loadSettings() {
        const darkMode = localStorage.getItem('expenseTracker_darkMode') === 'true';
        const notifications = localStorage.getItem('expenseTracker_notifications') === 'true';
        
        document.getElementById('darkModeToggle').checked = darkMode;
        document.getElementById('notificationsToggle').checked = notifications;
        
        if (darkMode) {
            document.documentElement.setAttribute('data-color-scheme', 'dark');
        }
    }

    toggleDarkMode(enabled) {
        if (enabled) {
            document.documentElement.setAttribute('data-color-scheme', 'dark');
        } else {
            document.documentElement.setAttribute('data-color-scheme', 'light');
        }
        
        localStorage.setItem('expenseTracker_darkMode', enabled.toString());
        
        // Re-render charts to update colors
        this.renderCharts();
        if (this.currentPageName === 'reports') {
            this.generateReport();
        }
    }

    exportData() {
        const data = {
            transactions: this.transactions,
            settings: {
                darkMode: localStorage.getItem('expenseTracker_darkMode'),
                notifications: localStorage.getItem('expenseTracker_notifications')
            },
            exportDate: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `expense-tracker-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        window.URL.revokeObjectURL(url);
        
        this.showNotification('Data exported successfully!', 'success');
    }

    importData(file) {
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                
                if (data.transactions && Array.isArray(data.transactions)) {
                    this.showConfirmModal(
                        'Import Data',
                        'This will replace all existing transactions. Are you sure you want to continue?',
                        () => {
                            this.transactions = data.transactions;
                            this.saveTransactions();
                            
                            if (data.settings) {
                                if (data.settings.darkMode) {
                                    localStorage.setItem('expenseTracker_darkMode', data.settings.darkMode);
                                }
                                if (data.settings.notifications) {
                                    localStorage.setItem('expenseTracker_notifications', data.settings.notifications);
                                }
                            }
                            
                            this.loadSettings();
                            this.updateSummaryCards();
                            this.renderCharts();
                            this.loadTransactionsPage();
                            
                            this.showNotification('Data imported successfully!', 'success');
                        }
                    );
                } else {
                    this.showNotification('Invalid file format', 'error');
                }
            } catch (error) {
                this.showNotification('Error reading file', 'error');
            }
        };
        
        reader.readAsText(file);
    }

    confirmClearData() {
        this.showConfirmModal(
            'Clear All Data',
            'This will permanently delete all transactions and cannot be undone. Are you sure?',
            () => {
                this.transactions = [];
                this.saveTransactions();
                this.updateSummaryCards();
                this.renderCharts();
                this.loadTransactionsPage();
                this.showNotification('All data cleared successfully!', 'success');
            }
        );
    }

    // Utility Functions
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span>${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-base);
            padding: var(--space-12) var(--space-16);
            box-shadow: var(--shadow-lg);
            z-index: 3000;
            min-width: 300px;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        
        if (type === 'success') {
            notification.style.borderLeftColor = 'var(--color-success)';
            notification.style.borderLeftWidth = '4px';
        } else if (type === 'error') {
            notification.style.borderLeftColor = 'var(--color-error)';
            notification.style.borderLeftWidth = '4px';
        }
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 10);
        
        // Auto remove
        const removeNotification = () => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.parentElement.removeChild(notification);
                }
            }, 300);
        };
        
        // Close button
        notification.querySelector('.notification-close').onclick = removeNotification;
        
        // Auto remove after 3 seconds
        setTimeout(removeNotification, 3000);
    }

    showModal(modalId) {
        document.getElementById(modalId).classList.remove('hidden');
    }

    hideModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
    }

    showConfirmModal(title, message, onConfirm) {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        this.pendingAction = onConfirm;
        this.showModal('confirmModal');
    }
}

// Initialize the application
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new ExpenseTracker();
});